import azure.functions as func
import logging
import tempfile
from pyspark.sql.functions import udf
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, DoubleType, StringType
from io import BytesIO

import time

spark = SparkSession \
    .builder \
    .appName("Python Spark SQL Q1 Vana") \
    .getOrCreate()

# Define the schema of the data
schema = StructType([
    StructField("key", StringType(), True),
    StructField("pickup_datetime", StringType(), True),
    StructField("pickup_longitude", DoubleType(), True),
    StructField("pickup_latitude", DoubleType(), True),
    StructField("dropoff_longitude", DoubleType(), True),
    StructField("dropoff_latitude", DoubleType(), True),
    StructField("passenger_count", DoubleType(), True)
])

# Define your UDF
@udf(returnType=StringType())
def calculate_quadrant_udf(latitude, longitude):
    latitude = float(latitude)
    longitude = float(longitude)
    center_latitude = 37.7833
    center_longitude = -122.4167
    if latitude > center_latitude and longitude > center_longitude:
        return "Q1"
    elif latitude > center_latitude and longitude < center_longitude:
        return "Q2"
    elif latitude < center_latitude and longitude > center_longitude:
        return "Q3"
    elif latitude < center_latitude and longitude < center_longitude:
        return "Q4"
    else:
        return "Unknown Quadrant"

app = func.FunctionApp()


# @app.blob_trigger(arg_name="myblob", path="mastercond/test_{number}.csv",
#                                connection="AzureWebJobsStorage") 
# def blob_triger_demo_01_q4(myblob: func.InputStream):
#     logging.info(f"Python blob trigger function processed blob"
#                 f"Name: {myblob.name}"
#                 f"Blob Size: {myblob.length} bytes"
#                 f"Blob Metadata: {myblob.metadata}")
    
#     temp_file_path = "/path/to/your/directory/tempfile.csv"
#     with open(temp_file_path, "wb") as temp_file:
#         temp_file.write(myblob.read())

#     df = spark.read.option("header", True).schema(schema).csv(temp_file_path)


#     # Read the blob data into a DataFrame
#     # df = spark.readStream.schema(schema).csv(myblob.url)

#     # Read the data from the temporary file into a DataFrame
#     df = spark.read.option("header", True).schema(schema).csv(temp_file.name)
    
#     # Use the UDF on the DataFrame
#     df = df.withColumn("quadrant", calculate_quadrant_udf(df["pickup_latitude"], df["pickup_longitude"]))

#     # Count the number of occurrences of each quadrant
#     quadrant_counts = df.groupBy("quadrant").count()

#     # Read the previous quadrant_counts from the CSV file
#     # if the file not exist ignore
#     try:
#         quadrant_counts = spark.read.option("header", True).csv("quadrant_counts")
#         quadrant_counts = quadrant_counts.adding(quadrant_counts)
#     except:
#         pass
    
#     quadrant_counts.show()

#     quadrant_counts.write.format("csv").save("quadrant_counts", mode="overwrite")

#     # Show the counts
#     # quadrant_counts.show()

#     # Write the stream to a CSV file
#     ## .outputMode("complete") \
    
#     # query = quadrant_counts.writeStream \
#     #     .outputMode("append") \
#     #     .format("parquet") \
#     #     .option("path", "quadrant_counts") \
#     #     .option("checkpointLocation", "quadrant_counts_checkpoints") \
#     #     .withWatermark("pickup_datetime", "1 hour") \
#     #     .start()

#     # query.awaitTermination()



@app.blob_trigger(arg_name="myblob", path="mastercond/test_{number}.csv",
                               connection="AzureWebJobsStorage") 
def blob_trigger_demo_01_q4(myblob: func.InputStream):
    logging.info(f"Python blob trigger function processed blob"
                 f"Name: {myblob.name}"
                 f"Blob Size: {myblob.length} bytes"
                 f"Blob Metadata: {myblob.metadata}")

     # Convert the InputStream to bytes and create a BytesIO object
    blob_content = BytesIO(myblob.read())

    # Convert BytesIO to string and split into lines
    blob_content_str = blob_content.getvalue().decode('utf-8')
    lines = blob_content_str.split('\n')

    # Convert lines to an RDD and then create a DataFrame
    rdd = spark.sparkContext.parallelize(lines)
    df = spark.read.option("header", True).schema(schema).csv(rdd)

    # Use the UDF on the DataFrame
    df = df.withColumn("quadrant", calculate_quadrant_udf(df["pickup_latitude"], df["pickup_longitude"]))

    # Count the number of occurrences of each quadrant
    quadrant_counts = df.groupBy("quadrant").count()

    # Read the previous quadrant_counts from the CSV file (if it exists)
    try:
        previous_counts = spark.read.option("header", True).csv("quadrant_counts")
        previous_counts.show()
        previous_counts = previous_counts.select("quadrant", previous_counts["count"].cast("double"))
        quadrant_counts = previous_counts.union(quadrant_counts).groupBy("quadrant").sum("count")
    except:
        pass

    quadrant_counts.show()

    # Write the updated quadrant_counts to a CSV file
    quadrant_counts.write.format("csv").save("quadrant_counts", mode="overwrite" , header=True)
